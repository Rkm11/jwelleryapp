<?php $this->load->view('backend/sections/header'); ?>
<link rel="stylesheet" href="<?php echo base_url(); ?>media/backend/css/jquery-ui.min.css"/>
<link href="<?php echo base_url(); ?>media/front/css/bootstrap-colorpicker.min.css" rel="stylesheet">
<?php $this->load->view('backend/sections/top-nav.php'); ?>
<?php $this->load->view('backend/sections/leftmenu.php'); ?>
<aside class="right-side">
    <section class="content-header">
        <h1>
            Update Product </li>    
        </h1>            
        <ol class="breadcrumb">
            <li> <a href="<?php echo base_url(); ?>backend/dashboard"><i class="fa fa-dashboard"></i> Dashboard</a>  </li>
            <li> <a href="<?php echo base_url(); ?>backend/products"><i class="fa fa-fw fa-retweet"></i> Manage  Product</a></li>
            <li class="active">Update Product</li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <form name="frm_edit_product" id="frm_edit_product" action="<?php echo base_url(); ?>backend/edit-product/<?php echo (base64_encode($product_information[0]['product_id'])); ?>" method="POST" enctype="multipart/form-data">
                        <div class="box-body">

                            <div class="form-group">
                                <label for="parametername">Product Name<sup class="mandatory">*</sup></label>
                                <input type="text" autofocus  class="form-control" id="product_name" name="product_name" value="<?php echo stripslashes(isset($product_information[0]['product_name'])) ? $product_information[0]['product_name'] : ''; ?>"   />
                            </div>
                            <div class="form-group">
                                <label for="parametername">Store Name<sup class="mandatory">*</sup></label>
                                <select class="form-control" id="store_id_fk" name="store_id_fk">
                                    <option value="">-Select Storefront-</option>
                                    <option value="">-No store-</option>
                                    <?php
                                    if (isset($storefronts) && count($storefronts) > 0) {
                                        foreach ($storefronts as $store) {
                                            if ($product_information[0]['store_id_fk'] != '' &&$product_information[0]['store_id_fk'] != '0' && $product_information[0]['store_id_fk'] == $store['store_id']) {
                                                $checked = 'selected="selected"';
                                            } else {
                                                $checked = "";
                                            }
                                            ?>
                                            <option value="<?php echo ($checked=="")?'selected=selected':''; ?>">No Store </option>
                                            <option value="<?php echo $store['store_id']; ?>" <?php echo $checked; ?>>
                                                <?php echo $store['store_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="parametername">Category<sup class="mandatory">*</sup></label>
                                <select class="form-control" id="parent_cat" name="parent_cat" disabled="">
                                    <option value="">-Select Category-</option>
                                    <?php
                                    if (isset($all_categories) && count($all_categories) > 0) {
                                        foreach ($all_categories as $paret_cat) {
                                            if ($product_information[0]['category_id'] != '' && $product_information[0]['category_id'] == $paret_cat['category_id']) {
                                                $checked = 'selected="selected"';
                                            } else {
                                                $checked = "";
                                            }
                                            ?>
                                            <option value="<?php echo $paret_cat['category_id']; ?>" <?php echo $checked; ?>>
                                                <?php echo $paret_cat['category_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="parametername">Sub Category<sup class="mandatory">*</sup></label>
                                <select class="form-control" id="sub_cat" name="sub_cat">
                                    <option value="">-Select Sub-Category-</option>
                                    <?php
                                    if (isset($sub_category) && count($sub_category) > 0) {
                                        foreach ($sub_category as $sub_cat) {
                                            if ($product_information[0]['sub_category_id'] != '' && $product_information[0]['sub_category_id'] == $sub_cat['category_id']) {
                                                $checked = 'selected="selected"';
                                            } else {
                                                $checked = "";
                                            }
                                            ?>
                                            <option value="<?php echo $sub_cat['category_id']; ?>" <?php echo $checked; ?>>
                                                <?php echo $sub_cat['category_name']; ?>
                                            </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                            <label class="col-md-4 col-sm-4 col-xs-12 control-label">Discount(%)<span class="mandatory">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <input type="text" name="discount" id="discount" placeholder="Discount(%)" class="form-control" value="<?php echo stripslashes(isset($product_information[0]['discount'])) ? $product_information[0]['discount'] : ''; ?>" >
                            </div>
                        </div>
                            <div class="form-group">
                                <label for="parametername">Product Price<sup class="mandatory">*</sup></label>
                                <input type="text" autofocus  class="form-control" id="product_price" name="product_price" value="<?php echo stripslashes(isset($product_information[0]['orignal_amount'])) ? $product_information[0]['orignal_amount'] : ''; ?>"   />
                            </div>

                            <div class="form-group">
                                <label>Size</label>
                                <input type="text" class="form-control" placeholder="Size" id="size" name="size" value="<?php echo stripslashes(isset($product_information[0]['size'])) ? $product_information[0]['size'] : ''; ?>">
                            </div>
                            <?php
                            $arr_clr = array();
                            if ($product_information[0]['product_color'] != '') {
                                $arr_clr = explode(',', $product_information[0]['product_color']);
                                $clr_count = count($arr_clr);
                            } else {
                                $arr_clr = array();
                                $clr_count = 0;
                            }
                            if (isset($arr_clr) && count($arr_clr) > 0) {
                                foreach ($arr_clr as $key => $color) {
                                    if ($key == 0) {
                                        ?>
                                        <div class="form-group">
                                            <label class="control-label">Color</label>
                                            <div class="row">
                                                <div class="controls  col-lg-11">
                                                    <div class="input-group demo-with-options_<?php echo $key; ?>">
                                                        <input type="text" value="" class="form-control" placeholder="Color" id="color_<?php echo $key; ?>" name="color[<?php echo $key; ?>]" />
                                                        <span class="input-group-addon"><i></i></span>
                                                    </div>
                                                </div>
                                                <div class="controls col-lg-1">
                                                    <a href="javascript:void(0);" title="add more Color" class="btn btn-success" id="add_new_color"><i class="fa fa-plus"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } else {
                                        ?>
                                        <div class="form-group current_color_row_<?php echo $key; ?>">
                                            <div class="row">
                                                <div class="controls  col-lg-11">
                                                    <div class="input-group demo-with-options_<?php echo $key; ?>">
                                                        <input type="text" value="" class="form-control" placeholder="Color" id="color_<?php echo $key; ?>" name="color[<?php echo $key; ?>]" />
                                                        <span class="input-group-addon"><i></i></span>
                                                    </div>
                                                </div>
                                                <div class="controls col-lg-1">
                                                    <a href="javascript:void(0);" title="Remove Color" class="btn btn-danger" id="remove_color_<?php echo $key; ?>" onclick="removeColor('<?php echo $key; ?>', '<?php echo $color; ?>', '<?php echo $product['product_id']; ?>');"><i class="fa fa-remove"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            } else {
                                ?>
                                <div class="form-group">
                                    <label class="control-label">Color</label>
                                    <div class="row">
                                        <div class="controls  col-lg-11">
                                            <div class="input-group demo-with-options_0">
                                                <input type="text" value="" class="form-control" placeholder="Color" id="color_0" name="color[]" />
                                                <span class="input-group-addon"><i class="fa fa-hand-o-up color" title="select color"></i></span>
                                            </div>
                                        </div>
                                        <div class="controls col-lg-1">
                                            <a href="javascript:void(0);" title="add more Color" class="btn btn-success" id="add_new_color"><i class="fa fa-plus"></i></a>
                                        </div>
                                    </div>
                                </div>
                            <?php }
                            ?>
                            <input type="hidden" value="<?php echo $clr_count - 1; ?>" class="form-group" id="clr_cnt" name="clr_cnt">
                            <div class="" id="more_color">
                            </div>
                            <div class="form-group">
                                <label for="parametername">Product Description<sup class="mandatory">*</sup></label>
                                <textarea type="text" autofocus  class="form-control" id="product_desc" name="product_desc"><?php echo stripslashes(isset($product_information[0]['product_description'])) ? $product_information[0]['product_description'] : ''; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="parametername">Product Quantity<sup class="mandatory">*</sup></label>
                                <input type="text" autofocus  class="form-control" id="quantity" name="quantity" value="<?php echo stripslashes(isset($product_information[0]['quantity'])) ? $product_information[0]['quantity'] : ''; ?>"   />
                            </div>
                            <div class="form-group">
                            <label class="col-md-4 col-sm-4 col-xs-12 control-label">Verified <sup class="mandatory">*</sup></label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select name="verified" id="verified" class="form-control">
                                    <option value="1" <?php echo ($product_information[0]['verified']=='1')?'selected=selected':''; ?> >Verified</option>
                                    <option value="0" <?php echo ($product_information[0]['verified']=='0')?'selected=selected':''; ?>>Not Verified</option>
                                </select>
                            </div>
                        </div>
                         <div class="form-group">
                            <label class="col-md-4 col-sm-4 col-xs-12 control-label">Select Status <sup class="mandatory">*</sup></label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <select name="product_status" id="product_status" class="form-control">
                                    <option value="1"<?php echo ($product_information[0]['product_status']=='1')?'selected=selected':''; ?> >Active</option>
                                    <option value="0"<?php echo ($product_information[0]['product_status']=='0')?'selected=selected':''; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                            <div class="form-group">
                                <label class="control-label" for="inputName">Previous Image<sup class="mandatory">*</sup></label>
                                <div class="controls">
                                    <?php
                                    if (isset($product['images']) && count($product['images'])) {
                                        $img = base_url() . "media/front/img/product-img/thumb/" . $product['images'][0]['image_name'];
                                    } else {
                                        $img = base_url() . "media/front/img/default.jpeg";
                                    }
                                    ?>
                                    <?php
                                    if (isset($product['images']) && count($product['images'])) {
                                        foreach ($product['images'] as $img) {
                                            if ($img['image_name'] != '') {
                                                $img_name = base_url() . "media/front/img/product-img/" . $img['image_name'];
                                            } else {
                                                $img_name = base_url() . "media/front/img/default.jpeg";
                                            }
                                            ?>
                                            <img src="<?php echo $img_name; ?>" width="90" height="90">	
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="">
                                    <input type="file" dir="ltr"  class="FETextInput" name="product_img[]" id="product_img" multiple="multiple" accept="image/*"/>
                                    <div for="product_img" id="error_file_size" generated="true" class="text-danger" style="display:none">Please upload only 6 images.</div>
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="submit" name="btnSubmit" class="btn btn-primary" id="btnSubmit" value="Save Changes">Save Changes</button>
                                <input type="hidden" name="edit_id" value="<?php echo $product_information[0]['product_id']; ?>">
                            </div>                  
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
        <?php $this->load->view('backend/sections/footer.php'); ?>  
        <script type="text/javascript">
<?php
if (isset($arr_clr) && count($arr_clr) > 0) {
    foreach ($arr_clr as $key => $color) {
        ?>
                                                    $('.demo-with-options_<?php echo $key; ?>').colorpicker({
                                                        color: '<?php echo $color; ?>',
                                                        format: 'hex'
                                                    });
        <?php
    }
}
?>

                                            function removeColor(id, value, product_id) {
                                                if (confirm("Are you sure you want to delete this record?"))
                                                {
                                                    $("#remove_color_" + id).attr('disabled', true);
                                                    $.ajax(
                                                            {
                                                                type: "POST",
                                                                url: "<?php echo base_url(); ?>backend-update-color",
                                                                data: {
                                                                    'clr_code': value,
                                                                    'product_id': product_id
                                                                },
                                                                success: function (data)
                                                                {
                                                                    $(".current_color_row" + id).remove();
                                                                    $("#remove_color_" + id).remove();
                                                                    j--;
                                                                    location.href = location.href;
                                                                }
                                                            });
                                                }
                                            }
        </script>
        </script>